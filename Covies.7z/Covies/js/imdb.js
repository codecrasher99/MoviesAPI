(function(){
    $(init);

    function init()
    {
        $("#search").click(searchMovie);

        function searchMovie()
        {
            var title = $("#searchText").val();
            alert('Searching for ' + title);

            var data = new Object();
            data.moviename = title;
            data =  JSON.stringify(data);

            alert(data);
            console.log(data);

            $.ajax({
                type: "POST",
                contentType: "application/json",
                data: data,
                url: "https://prod-28.westeurope.logic.azure.com:443/workflows/8457178292734043ada5fdbb2037e4de/triggers/manual/paths/invoke?api-version=2016-10-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=Fja45P0U5aCrxGWT90ca15zcgC7hxaQEw2gnRe0WQwM",
                success: function(response) {
                    alert(response);
                    console.log(response);
                }

            });
        }
    }
})();